var searchData=
[
  ['suma',['suma',['../class_operacions.html#a76ec537d73d15ad2e5ff2178dff13dd1',1,'Operacions']]]
];

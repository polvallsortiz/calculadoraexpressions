var searchData=
[
  ['dades',['Dades',['../class_dades.html#a3f15514e0dc3616e732da2410c28eb17',1,'Dades']]]
];

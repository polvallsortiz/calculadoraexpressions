var searchData=
[
  ['operacions',['Operacions',['../class_operacions.html#abc10463e3791ee47bfb229f662b31b21',1,'Operacions']]]
];

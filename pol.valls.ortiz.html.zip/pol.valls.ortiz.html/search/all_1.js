var searchData=
[
  ['comparacio_5fand',['comparacio_AND',['../class_operacions.html#a405c9ce8170a9f46bc4c37372ea4869d',1,'Operacions']]],
  ['comparacio_5for',['comparacio_OR',['../class_operacions.html#a791230f309f065185f1344a0fd8bf2f7',1,'Operacions']]]
];

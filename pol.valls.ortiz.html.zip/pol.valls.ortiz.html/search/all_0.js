var searchData=
[
  ['afegidor',['afegidor',['../class_operacions.html#a4c0d627a0cd0f687d464377545f81737',1,'Operacions']]],
  ['afegir_5fdada_5fentera',['afegir_dada_entera',['../class_dades.html#a1a545c0896bb01c8f046e50b4d059e1d',1,'Dades']]],
  ['afegir_5fdada_5fllista',['afegir_dada_llista',['../class_dades.html#ada957cf8c32a79668ef7fd0306deff17',1,'Dades']]],
  ['afegir_5foperacio',['afegir_operacio',['../class_operacions.html#acd4b4d5713f1284897948944f82052db',1,'Operacions']]]
];

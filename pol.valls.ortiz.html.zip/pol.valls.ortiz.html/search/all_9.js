var searchData=
[
  ['petit',['petit',['../class_operacions.html#a3502ad219b24ba904ec078c08777e9fa',1,'Operacions']]],
  ['pop_5fllista',['pop_llista',['../class_operacions.html#ae09b90231ad3253b30dcf093a426eb5e',1,'Operacions']]]
];

var searchData=
[
  ['operacions_2ehh',['Operacions.hh',['../_operacions_8hh.html',1,'']]]
];

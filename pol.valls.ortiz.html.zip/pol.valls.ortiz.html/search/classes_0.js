var searchData=
[
  ['dades',['Dades',['../class_dades.html',1,'']]]
];

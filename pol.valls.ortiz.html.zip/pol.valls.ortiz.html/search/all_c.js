var searchData=
[
  ['valor_5fenter',['valor_enter',['../class_dades.html#afcef8e843811361241801507d5b63d8e',1,'Dades']]],
  ['valor_5fllista',['valor_llista',['../class_dades.html#aab421c7fae35e4cc07ef5d4b28d84eb3',1,'Dades']]]
];

var searchData=
[
  ['llegir_5fexpressio',['llegir_expressio',['../class_expressio.html#a8fd9f3a9abc26b72e8a3faef62be0ef1',1,'Expressio']]]
];

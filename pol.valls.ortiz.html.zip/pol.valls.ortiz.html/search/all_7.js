var searchData=
[
  ['negacio',['negacio',['../class_operacions.html#a15c04d0edfdd931ae32b54f7a5151480',1,'Operacions']]]
];

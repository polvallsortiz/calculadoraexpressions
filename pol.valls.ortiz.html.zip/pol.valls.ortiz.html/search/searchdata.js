var indexSectionsWithContent =
{
  0: "acdeilmnopstv",
  1: "deo",
  2: "demo",
  3: "acdeilmnopstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions"
};


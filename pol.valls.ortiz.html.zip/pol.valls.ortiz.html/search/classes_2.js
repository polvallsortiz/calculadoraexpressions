var searchData=
[
  ['operacions',['Operacions',['../class_operacions.html',1,'']]]
];

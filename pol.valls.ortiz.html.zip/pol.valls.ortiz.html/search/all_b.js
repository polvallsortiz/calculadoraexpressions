var searchData=
[
  ['top_5fllista',['top_llista',['../class_operacions.html#a5e3dcfde896020a826117d5e7476cd61',1,'Operacions']]]
];

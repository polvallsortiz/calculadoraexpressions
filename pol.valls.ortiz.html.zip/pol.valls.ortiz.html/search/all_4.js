var searchData=
[
  ['if_5fy_5fz',['if_y_z',['../class_operacions.html#a83fda7bdd70c477b94b8f212ea3cbee3',1,'Operacions']]],
  ['igualtat',['igualtat',['../class_operacions.html#a6800ee5752a63a5e9c8d3f223eb7a594',1,'Operacions']]],
  ['intercanviador',['intercanviador',['../class_operacions.html#a2dce5baf794dd128ebdaceab45e39898',1,'Operacions']]]
];
